using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class carsonTest : MonoBehaviour
{
    
    public void carsonTestFunc () {
        Debug.Log("Ballsagna");
    }
    
    // Start is called before the first frame update
    void Start() {
        carsonTestFunc();
    }
    
}
